require 'test_helper'

class RunResultTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
